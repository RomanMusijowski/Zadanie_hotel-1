package com.zadanie.roman_musiiovskyi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RomanMusiiovskyiApplication {

	public static void main(String[] args) {
		SpringApplication.run(RomanMusiiovskyiApplication.class, args);
	}

}
